export default function NotFound() {

  return <>
    <h1 className={'text-3xl'}>Not Found</h1>
  </>
}
