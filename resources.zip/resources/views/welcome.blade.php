<!DOCTYPE html>
<html>
<head>
  <title>RecInterview</title>
  @viteReactRefresh
  @vite(['resources/css/app.css', 'resources/js/app.jsx'])
</head>
<body>
  <div id="react-app"></div>
</body>
</html>
