import SignIn from "../components/user/SignIn.jsx";

export default function Login() {

  return <>
    <SignIn/>
  </>
}
